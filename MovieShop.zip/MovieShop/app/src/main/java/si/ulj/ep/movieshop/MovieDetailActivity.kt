package si.ulj.ep.movieshop

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.util.Log
import kotlinx.android.synthetic.main.activity_movie_detail.*
import kotlinx.android.synthetic.main.content_movie_detail.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.IOException
import java.util.*

class MovieDetailActivity : AppCompatActivity(), Callback<Movie> {

    private var movie: Movie? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_detail)
        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val id = intent.getIntExtra("si.ulj.ep.movieshop.id", 0)

        if (id > 0) {
            MovieService.instance.get(id).enqueue(this)
        }
    }

    override fun onResponse(call: Call<Movie>, response: Response<Movie>) {
        movie = response.body()
        Log.i(TAG, "Got result: $movie")

        if (response.isSuccessful) {
            toolbarLayout.title = movie?.title
            tvDirector.text = movie?.director
            tvPrice.text = String.format(Locale.ENGLISH, "%.2f EUR", movie?.price)
            tvRunlength.text = String.format(Locale.ENGLISH, "%d min", movie?.runlength)
            tvYear.text = movie?.year.toString()
            tvMovieDetail.text = movie?.description
            ratingBar.rating = movie?.score ?: 0.0f
        } else {
            val errorMessage = try {
                "An error occurred: ${response.errorBody()?.string()}"
            } catch (e: IOException) {
                "An error occurred: error while decoding the error message."
            }

            Log.e(TAG, errorMessage)
            tvMovieDetail.text = errorMessage
        }
    }

    override fun onFailure(call: Call<Movie>, t: Throwable) {
        Log.w(TAG, "Error: ${t.message}", t)
    }

    companion object {
        private val TAG = MovieDetailActivity::class.java.canonicalName
    }
}
