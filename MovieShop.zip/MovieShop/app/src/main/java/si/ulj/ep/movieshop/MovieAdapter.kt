package si.ulj.ep.movieshop

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import java.util.*

class MovieAdapter(context: Context) : ArrayAdapter<Movie>(context, 0, ArrayList()) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        // Check if an existing view is being reused, otherwise inflate the view
        val view = if (convertView == null)
            LayoutInflater.from(context).inflate(R.layout.movielist_element, parent, false)
        else
            convertView

        val tvTitle = view.findViewById<TextView>(R.id.tvTitle)
        val tvRunlength = view.findViewById<TextView>(R.id.tvRunlength)
        val tvPrice = view.findViewById<TextView>(R.id.tvPrice)


        val movie = getItem(position)

        tvTitle.text = movie?.title
        tvRunlength.text = String.format(Locale.ENGLISH, "%d min", movie?.runlength)
        tvPrice.text = String.format(Locale.ENGLISH, "%.2f EUR", movie?.price)

        return view
    }
}
