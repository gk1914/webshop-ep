package si.ulj.ep.movieshop

import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

object MovieService {

    interface RestApi {

        companion object {
            const val URL = "http://192.168.1.70:80/netbeans/movieshop/api/"
        }

        @GET("movies")
        fun getAll(): Call<List<Movie>>

        @GET("movies/{id}")
        fun get(@Path("id") id: Int): Call<Movie>
    }

    val instance: RestApi by lazy {
        val retrofit = Retrofit.Builder()
                .baseUrl(RestApi.URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()

        retrofit.create(RestApi::class.java)
    }
}
