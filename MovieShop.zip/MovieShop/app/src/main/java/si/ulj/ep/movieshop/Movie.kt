package si.ulj.ep.movieshop

import java.io.Serializable

data class Movie(
        val id: Int = 0,
        val title: String = "",
        val director: String = "",
        val year: Int = 0,
        val runlength: Int = 0,
        val description: String = "",
        val price: Double = 0.0,
        val score: Float = 0.0f) : Serializable
